package com.example.bes_bekar_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
