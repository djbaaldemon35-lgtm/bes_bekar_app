#!/bin/bash
export PATH="$PATH:/home/user/flutter/bin"
flutter pub get
