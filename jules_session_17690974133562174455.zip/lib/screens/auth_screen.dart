import 'package:flutter/material.dart';

class AuthScreen extends StatelessWidget {
  const AuthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Giriş')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('Telefon numarası veya sosyal hesap ile anında giriş'),
            const SizedBox(height: 16),
            TextField(
              decoration: const InputDecoration(labelText: 'Telefon numarası', prefixText: '+90 '),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {
                // SMS doğrulama iste
                Navigator.pushReplacementNamed(context, '/home');
              },
              child: const Text('Hızlı Giriş'),
            ),
            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.login),
              label: const Text('Google ile devam et'),
            ),
          ],
        ),
      ),
    );
  }
}
