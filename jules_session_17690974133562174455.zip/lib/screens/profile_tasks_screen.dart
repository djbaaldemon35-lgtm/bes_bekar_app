import 'package:flutter/material.dart';

class ProfileTasksScreen extends StatelessWidget {
  const ProfileTasksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Profile Tasks Screen'),
      ),
    );
  }
}
