import 'package:flutter/material.dart';

class SwipeMatchScreen extends StatelessWidget {
  const SwipeMatchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Arka planda kartlar
          Center(
            child: Container(
              width: 320,
              height: 480,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                color: Colors.grey[900],
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ListTile(
                    title: Text('Kullanıcı Adı'),
                    subtitle: Text('25 • İzmir'),
                  ),
                ],
              ),
            ),
          ),
          // Altta butonlar
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 32),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  FloatingActionButton(onPressed: () {}, child: const Icon(Icons.clear)),
                  FloatingActionButton(onPressed: () {}, child: const Icon(Icons.star)),
                  FloatingActionButton(onPressed: () {}, child: const Icon(Icons.favorite)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
