import 'package:flutter/material.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        children: const [
          _OnboardPage(title: 'Hızlı Tanış', description: 'Konum tabanlı eşleşmeler.'),
          _OnboardPage(title: 'Premium İçerik', description: 'Creator profillerine abone ol.'),
          _OnboardPage(title: 'Güvenli Doğrulama', description: 'Selfie ile doğrulanmış profiller.'),
        ],
      ),
      bottomNavigationBar: _OnboardControls(),
    );
  }
}

class _OnboardPage extends StatelessWidget {
  final String title;
  final String description;
  const _OnboardPage({required this.title, required this.description});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(title, style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 12),
            Text(description, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class _OnboardControls extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          TextButton(onPressed: () => Navigator.pushReplacementNamed(context, '/auth'), child: const Text('Atla')),
          ElevatedButton(onPressed: () {/* page forward */}, child: const Text('İleri')),
        ],
      ),
    );
  }
}
