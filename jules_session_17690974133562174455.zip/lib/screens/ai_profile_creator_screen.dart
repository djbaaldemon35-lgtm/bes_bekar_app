import 'package:flutter/material.dart';

class AIProfileCreatorScreen extends StatelessWidget {
  const AIProfileCreatorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('AI Profile Creator Screen'),
      ),
    );
  }
}
