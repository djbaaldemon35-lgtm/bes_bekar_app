import 'package:flutter/material.dart';

class SelfieValidationScreen extends StatelessWidget {
  const SelfieValidationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Selfie Validation Screen'),
      ),
    );
  }
}
