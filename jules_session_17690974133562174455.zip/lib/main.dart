import 'package:flutter/material.dart';
import 'routes.dart';

void main() {
  runApp(const BesBekarApp());
}

class BesBekarApp extends StatelessWidget {
  const BesBekarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BesBekar',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      initialRoute: '/splash',
      onGenerateRoute: AppRoutes.onGenerateRoute,
    );
  }
}
