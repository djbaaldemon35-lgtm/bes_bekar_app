import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/swipe_match_screen.dart';
import 'screens/chat_list_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/creator_profile_screen.dart';
import 'screens/explore_screen.dart';
import 'screens/live_stream_screen.dart';
import 'screens/subscription_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/profile_completion_screen.dart';
import 'screens/ai_profile_creator_screen.dart';
import 'screens/profile_tasks_screen.dart';
import 'screens/selfie_validation_screen.dart';

class AppRoutes {
  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/splash':
        return MaterialPageRoute(builder: (_) => const SplashScreen());
      case '/onboarding':
        return MaterialPageRoute(builder: (_) => const OnboardingScreen());
      case '/auth':
        return MaterialPageRoute(builder: (_) => const AuthScreen());
      case '/home':
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case '/swipe':
        return MaterialPageRoute(builder: (_) => const SwipeMatchScreen());
      case '/chats':
        return MaterialPageRoute(builder: (_) => const ChatListScreen());
      case '/chat':
        return MaterialPageRoute(builder: (_) => const ChatScreen());
      case '/profile':
        return MaterialPageRoute(builder: (_) => const ProfileScreen());
      case '/creator-profile':
        return MaterialPageRoute(builder: (_) => const CreatorProfileScreen());
      case '/explore':
        return MaterialPageRoute(builder: (_) => const ExploreScreen());
      case '/live':
        return MaterialPageRoute(builder: (_) => const LiveStreamScreen());
      case '/subscription':
        return MaterialPageRoute(builder: (_) => const SubscriptionScreen());
      case '/settings':
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      case '/profile-completion':
        return MaterialPageRoute(builder: (_) => const ProfileCompletionScreen());
      case '/ai-profile':
        return MaterialPageRoute(builder: (_) => const AIProfileCreatorScreen());
      case '/profile-tasks':
        return MaterialPageRoute(builder: (_) => const ProfileTasksScreen());
      case '/selfie-validation':
        return MaterialPageRoute(builder: (_) => const SelfieValidationScreen());
      default:
        return MaterialPageRoute(builder: (_) => const SplashScreen());
    }
  }
}
